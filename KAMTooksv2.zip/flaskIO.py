# all the imports
from flask import Flask, request, session, g, redirect, url_for, abort, \
     render_template, flash
from flask import Flask, flash, redirect, render_template, request, session, abort
import os
import json
import urllib2
from forms import RegistrationForm, RequirementDropDown
from static.data.spData import dataRec, busNeedToDeliverable, busNeedToSolution, deliverablesToBusNeed, \
                                deliverablesToSolution, solutionToNeed, solutionToDel


###BIJAN's Core application and data imports and builds
from gensim import corpora, models, similarities
from os import listdir
from os.path import isfile, join
from collections import defaultdict
from pprint import pprint

path = "KAMTData"
files = [f for f in listdir(path) if isfile(join(path, f))]

documents = []
for f in files:
    file = open(path+"/"+f, 'r')
    documents.append(file.read())
    file.close()

stoplist = set('for a of the and to in'.split())
texts = [[word for word in document.lower().split() if word not in stoplist]
         for document in documents]


frequency = defaultdict(int)
for text in texts:
     for token in text:
         frequency[token] += 1

texts = [[token for token in text if frequency[token] > 1]
          for text in texts]

dictionary = corpora.Dictionary(texts)
dictionary.save('tmp/deerwester.dict') # store the dictionary, for future reference
#print(dictionary)

corpus = [dictionary.doc2bow(text) for text in texts]
corpora.MmCorpus.serialize('tmp/deerwester.mm', corpus) # store to disk, for later use

dictionary = corpora.Dictionary.load('tmp/deerwester.dict')
corpus = corpora.MmCorpus('tmp/deerwester.mm')
#print(corpus)

lsi = models.LsiModel(corpus, id2word=dictionary, num_topics=34)


##MARK's build - the FLASK interface and required connectors to data
tmpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
app = Flask(__name__, template_folder=tmpl_dir)


def getSankeyData():
    knowledge = []
    knowledgeList = []
    count = 0
    for key, value in dataRec.iteritems():
         knowledge.append(key)
         for endings in value:
              knowledge.append(endings)
              knowledge.append(5)
              knowledgeList.append(knowledge)
              knowledge = []
              if count < len(value) - 1:
                   knowledge.append(key)
                   count += 1
              else:
                   count = 0
    return knowledgeList


def getWordTreeData(kmRequirement):
    """['id', 'childLabel', 'parent', 'size', { role: 'style' }],
        [0, 'Brainstorm', -1, 1, 'black'],
        [1, 'DELIVERABLE', 0, 1, 'red'],
        [2, 'Knowledge Map', 1, 5, 'red'],
        [3, 'SOFTWARE', 0, 8, 'purple'],
        [4, 'Adobe', 3, 2, 'purple'],
        [5, 'Camtasia', 3, 2, 'purple'],
        [6, 'Lync', 3, 2, 'purple'],
        [7, 'nVivo', 3, 2, 'purple'],
        [8, 'Prezi', 3, 2, 'purple']]);"""
    if kmRequirement == 'BUSINESS NEED':
        print "WOW"#do something
        # Build Deliverable
    dictKey = 'Collaboration'
    knowledge = []
    knowledgeList = []
    index = 0
    knowledge = [index, dictKey, -1, 1, 'black']
    knowledgeList.append(knowledge)
    knowledge = []
    index += 1
    knowledge = [index, 'DELIVERABLE', index - 1, 1, 'red']
    parentIndex = index
    knowledgeList.append(knowledge)
    knowledge = []
    index += 1
    for value in busNeedToDeliverable[dictKey]:
        knowledge = [index, value, parentIndex, 1, 'red']
        knowledgeList.append(knowledge)
        knowledge = []
        index += 1

    # Build Software Component
    knowledge = [index, 'SOFTWARE', parentIndex - 1, 1, 'purple']
    knowledgeList.append(knowledge)
    knowledge = []
    parentIndex = index
    index += 1
    for value in busNeedToSolution[dictKey]:
        knowledge = [index, value, parentIndex, 1, 'purple']
        knowledgeList.append(knowledge)
        knowledge = []
        index += 1
    return knowledgeList


def getExchangeRates():
    rates = []
    response = urllib2.urlopen('http://api.fixer.io/latest')
    data = response.read()
    rdata = json.loads(data, parse_float=float)

    rates.append(rdata['rates']['USD'])
    rates.append(rdata['rates']['GBP'])
    rates.append(rdata['rates']['HKD'])
    rates.append(rdata['rates']['AUD'])
    return rates

def getAllData():
    json1 = json.dumps(busNeedToDeliverable, ensure_ascii=False)
    json2 = json.dumps(busNeedToSolution, ensure_ascii=False)
    json3 = json.dumps(deliverablesToBusNeed, ensure_ascii=False)
    json4 = json.dumps(deliverablesToSolution, ensure_ascii=False)
    json5 = json.dumps(solutionToNeed, ensure_ascii=False)
    json6 = json.dumps(solutionToDel, ensure_ascii=False)
    return json1, json2, json3, json4, json5, json6

def getWebListData():
    import urllib2
    response = urllib2.urlopen('https://share.ahsnet.ca/teams/kmqa/_vti_bin/owssvr.dll?Cmd=Display&XMLDATA=TRUE&List={9DC112D0-A174-4C6E-93A2-C46287E0530E}')
    html = response.read()
    print html

########### ROUTING OPTIONS ###############
@app.route("/test")
def test():
    return render_template('test.html', **locals())

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RequirementDropDown(request.form)
    rates = getExchangeRates()
    if request.method == 'POST' and form.validate():
        business = form.BusDropDown.data
        flash('Thanks for registering')
        return redirect(url_for('register'))
    return render_template('test.html', form=form, rates=rates)

@app.route("/formSelect")
def formSelect():
    form = RequirementDropDown(request.form)
    return render_template('formSelect.html', form=form)

@app.route("/wordtree")
def wordtree():
    json1, json2, json3, json4, json5, json6 = getAllData()
    return render_template('wordTree.html', **locals())

@app.route("/sankey")
def sankey():
    json1, json2, json3, json4, json5, json6 = getAllData()
    return render_template('sankey.html', **locals())

@app.route("/sankeyTest")
def sankeyTest():
    json1, json2, json3, json4, json5, json6 = getAllData()
    return render_template('sankeyAI.html', **locals())

@app.route("/hello")
def hello():
    return render_template('columnMap.html', **locals())

@app.route("/")
def home():
    return render_template('home.html', **locals())

## BIJAN's MAGIC
"""
@app.route("/int2")
def initial():
    return '<form action="/ask" method="POST"><input name="text" size = "200"><input type="submit" value="Go"></form>'
"""
@app.route("/ask", methods=['POST'])
def ask():
    directResponse = []
    askText = request.form['text']
    if askText != '':
        doc = askText
        vec_bow = dictionary.doc2bow(doc.lower().split())
        vec_lsi = lsi[vec_bow]  # convert the query to LSI space
        # print(vec_lsi)

        index = similarities.MatrixSimilarity(lsi[corpus])  # transform corpus to LSI space and index it
        index.save('tmp/deerwester.index')
        index = similarities.MatrixSimilarity.load('tmp/deerwester.index')

        sims = index[vec_lsi]  # perform a similarity query against the corpus
        sims = sorted(enumerate(sims), key=lambda item: -item[1])
        # print(sims)
        if sims[0][1]==0: response = 'I could not find a good answer for you, please explain more about what you are doing.'
        else:
            response = "You may find the tool that your are looking for \n" \
                       "in one or few of the following deliverables (please note the deliverable column)." \
                       "If the results did not help you please" \
                       " navigate manually."
            for i in range(10):
                response += " " + str(i + 1) + " " + (documents[sims[i][0]].split(":")[0])
                directResponse.append((documents[sims[i][0]].split(":")[0]))
    else:
        response = "You did not enter anything!"
    json1, json2, json3, json4, json5, json6 = getAllData()
    json7 = json.dumps(directResponse, ensure_ascii=False)
    return render_template('sankeyAI.html', **locals())
    #response += '<form action="/"><input type="submit" value="Let me try again"></form>'
    #return response


if __name__ == "__main__":
    app.run(host='0.0.0.0')

